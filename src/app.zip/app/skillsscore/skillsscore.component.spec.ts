/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { SkillsscoreComponent } from './skillsscore.component';

describe('Component: Skillsscore', () => {
  it('should create an instance', () => {
    let component = new SkillsscoreComponent();
    expect(component).toBeTruthy();
  });
});
