/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { TestcomponentComponent } from './testcomponent.component';

describe('Component: Testcomponent', () => {
  it('should create an instance', () => {
    let component = new TestcomponentComponent();
    expect(component).toBeTruthy();
  });
});
