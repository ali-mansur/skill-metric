export class SkillMatrixProfile {
  eId: string;
  name: string;
  designation: string;
  profileImage: string;
  skills: string;
  graph : any;
}