export class skilldata {
  id: number;
  name: string;
}